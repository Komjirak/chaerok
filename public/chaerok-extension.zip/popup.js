import { extractPayload } from './capture.js';
import { NOTES_URL, openSaveWindow } from './config.js';

/**
 * 팝업 — 무엇이 담길지 먼저 보여주고 나서 담는다.
 *
 * 미리보기를 두는 이유: 클리퍼는 "무엇이 저장됐는지 모르겠다"가 가장 흔한
 * 불만이다. 제목과 주소, 선택 영역 여부를 눌러보기 전에 확인시킨다.
 */

const $ = (id) => document.getElementById(id);
let payload = null;

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return offer(null, tab);

  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPayload,
    });
    offer(result, tab);
  } catch {
    // chrome:// 이나 스토어 페이지는 주입이 막혀 있다 — 주소만 담을 수 있다
    offer(null, tab);
  }
}

function offer(result, tab) {
  payload = result ?? { url: tab?.url ?? '', title: tab?.title ?? '', text: '', fromSelection: false };

  $('title').textContent = payload.title || '(제목 없음)';
  $('url').textContent = short(payload.url);
  $('sel').classList.toggle('hide', !payload.fromSelection);

  const clip = $('clip');
  clip.disabled = !payload.url;
  if (!payload.url) $('title').textContent = '이 페이지는 담을 수 없어요';
}

/** 추적 파라미터를 표시에서만 걷어낸다 — 앱·웹과 같은 규칙 */
function short(raw) {
  try {
    const u = new URL(raw);
    for (const k of [...u.searchParams.keys()]) {
      if (k.toLowerCase().startsWith('utm_')) u.searchParams.delete(k);
    }
    return u.host + u.pathname + (u.search || '');
  } catch {
    return raw ?? '';
  }
}

$('clip').addEventListener('click', async () => {
  if (!payload) return;
  await openSaveWindow(payload);
  window.close();
});

$('open-notes').addEventListener('click', (e) => {
  e.preventDefault();
  void chrome.tabs.create({ url: NOTES_URL });
  window.close();
});

void init();

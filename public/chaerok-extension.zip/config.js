/**
 * 익스텐션 설정.
 *
 * 저장 자체는 웹 사이트의 /save 페이지가 처리한다 — 익스텐션은 페이지를 긁어
 * 넘기는 일만 한다. 그 이유는 그 페이지 주석에 적어뒀다(MV3에서 로그인 팝업 제약).
 *
 * 웹은 별도 저장소에 있다: github.com/Komjirak/chaerok (Vercel 배포)
 */

/**
 * 커스텀 도메인을 쓰게 되면 이 값만 바꾼다.
 * 로컬에서 시험할 때는 http://localhost:3000 으로 둔다.
 */
export const WEB_ORIGIN = 'https://chaerok.komjirak.studio';

export const SAVE_URL = `${WEB_ORIGIN}/save`;
export const NOTES_URL = `${WEB_ORIGIN}/notes`;

/** 담기 창 크기 — 폰의 공유 시트와 비슷한 비율로 둔다 */
export const WINDOW_SIZE = { width: 460, height: 640 };

/**
 * 최종 URL 길이 상한. Vercel이 요청 URI 14KB 초과에 414(URI_TOO_LONG)를
 * 돌려주므로 그 아래에 여유를 두고 자른다. 글자 수 제한(capture.js의 6000자)만으로는
 * 부족하다 — 한글은 percent 인코딩에서 글자당 9바이트로 불어나
 * 한글 본문 6000자가 URL로는 50KB를 넘길 수 있다.
 */
const MAX_URL_LENGTH = 12000;

/**
 * 담기 창을 연다.
 *
 * 페이지 내용을 쿼리로 넘긴다. chrome.storage는 웹 페이지가 읽을 수 없고
 * postMessage는 창이 준비될 때까지 기다려야 해서, 발췌를 6000자로 제한하는
 * 대신 경로를 단순하게 뒀다. 요약에 그보다 긴 본문이 필요하지도 않다.
 */
export async function openSaveWindow(payload) {
  const base = {
    url: payload.url ?? '',
    title: (payload.title ?? '').slice(0, 300),
  };
  const build = (text) => `${SAVE_URL}?${new URLSearchParams({ ...base, text })}`;

  let text = payload.text ?? '';
  if (build(text).length > MAX_URL_LENGTH) {
    // 인코딩된 길이가 한도에 들어오는 가장 긴 절단점을 이분 탐색으로 찾는다
    let lo = 0;
    let hi = text.length;
    while (lo < hi) {
      const mid = Math.ceil((lo + hi) / 2);
      if (build(text.slice(0, mid)).length > MAX_URL_LENGTH) hi = mid - 1;
      else lo = mid;
    }
    text = text.slice(0, lo);
  }

  await chrome.windows.create({
    url: build(text),
    type: 'popup',
    width: WINDOW_SIZE.width,
    height: WINDOW_SIZE.height,
  });
}

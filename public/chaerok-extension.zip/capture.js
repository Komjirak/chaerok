/**
 * 페이지에서 담을 재료를 긁어낸다.
 *
 * `chrome.scripting.executeScript`로 주입되므로 **의존성이 없어야 하고
 * 반환값이 직렬화 가능해야 한다.** 그래서 한 함수로 끝낸다.
 *
 * 선택 영역이 있으면 그것을 우선한다 — 사용자가 특정 부분을 골라둔 것은
 * "이걸 담고 싶다"는 명확한 신호다. 없으면 본문을 찾아 발췌한다.
 */
export function extractPayload() {
  const CAP = 6000;

  const selection = String(window.getSelection?.() ?? '').trim();

  /** 본문 후보를 좁혀간다 — 사이드바·댓글·광고를 피하려는 것 */
  const pickBody = () => {
    const candidates = [
      document.querySelector('article'),
      document.querySelector('main'),
      document.querySelector('[role="main"]'),
      document.querySelector('#content, .article-body, .post-content'),
      document.body,
    ].filter(Boolean);

    for (const node of candidates) {
      const text = (node.innerText ?? '').replace(/\n{3,}/g, '\n\n').trim();
      // 너무 짧으면 본문이 아니다(내비게이션만 잡힌 경우)
      if (text.length > 200) return text;
    }
    return (document.body?.innerText ?? '').trim();
  };

  const text = (selection || pickBody()).slice(0, CAP);

  /** og:title이 사람이 읽기 좋은 경우가 많다 */
  const meta = (prop) =>
    document.querySelector(`meta[property="${prop}"], meta[name="${prop}"]`)?.content?.trim() ?? '';

  return {
    url: location.href,
    title: meta('og:title') || document.title || '',
    text,
    /** 선택 영역이었는지 — 담기 창에서 안내 문구가 달라진다 */
    fromSelection: selection.length > 0,
  };
}

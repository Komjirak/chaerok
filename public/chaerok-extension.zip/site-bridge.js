/**
 * 채록 웹 사이트에만 주입되는 아주 작은 다리.
 *
 * 하는 일은 하나 — **설치돼 있다는 표시를 DOM에 남긴다.** 소개 페이지의
 * 설치 버튼이 이 표시를 보고 "크롬에 추가"와 "이미 설치됨"을 구분한다.
 *
 * 왜 메시지가 아니라 DOM인가: `externally_connectable`로 메시지를 주고받으려면
 * 페이지가 익스텐션 ID를 알아야 하는데, 스토어에 올리기 전과 후의 ID가 다르다.
 * 배포처마다 상수를 고쳐야 하는 구조를 만들 이유가 없다. 콘텐츠 스크립트는
 * 격리된 세계에서 돌지만 **DOM은 페이지와 공유하므로** 이 표시는 그대로 읽힌다.
 *
 * 남기는 값은 버전뿐이다. 페이지 쪽으로 나가는 정보가 더 있을 이유가 없다.
 */

const version = chrome.runtime.getManifest().version;

document.documentElement.dataset.chaerokExtension = version;

// 페이지가 스크립트를 늦게 올리는 경우가 있어(React 하이드레이션) 신호도 함께 쏜다.
// 이미 붙어 있는 dataset을 읽는 쪽이 기본이고, 이건 보조다.
document.dispatchEvent(new CustomEvent('chaerok:extension-ready', { detail: { version } }));

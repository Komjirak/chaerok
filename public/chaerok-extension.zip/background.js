import { extractPayload } from './capture.js';
import { openSaveWindow } from './config.js';

/**
 * 서비스 워커 — 우클릭 메뉴와 단축키를 처리한다.
 *
 * 팝업을 거치지 않는 경로다. 읽다가 문단을 선택하고 바로 담는 게 가장 자연스러운
 * 사용 흐름인데, 그때 팝업을 열게 하면 선택이 풀린다.
 */

const MENU_ID = 'chaerok-clip';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: '채록에 담기',
    contexts: ['page', 'selection', 'link'],
  });
});

async function clip(tab) {
  if (!tab?.id) return;

  // chrome:// 같은 페이지에는 스크립트를 넣을 수 없다 — 주소만이라도 담는다
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPayload,
    });
    await openSaveWindow(result);
  } catch {
    await openSaveWindow({ url: tab.url ?? '', title: tab.title ?? '', text: '' });
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU_ID) return;
  // 링크를 우클릭했으면 그 링크를 담는다
  if (info.linkUrl) {
    void openSaveWindow({ url: info.linkUrl, title: info.selectionText || info.linkUrl, text: '' });
    return;
  }
  void clip(tab);
});

chrome.commands.onCommand.addListener((command, tab) => {
  if (command === 'clip') void clip(tab);
});
